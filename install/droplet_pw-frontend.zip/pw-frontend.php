//:show pw generator in frontend
//:[[pw-frontend]]

return pw_generator::getInstance()->display_frontend();